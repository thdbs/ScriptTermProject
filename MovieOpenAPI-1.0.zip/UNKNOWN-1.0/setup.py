from distutils.core import setup

setup(
    version = '1.0',
    py_modules = ['BookMarkIO', 'BookMarkModule', 'BoxOffice', 'Dialog', 'movieSearch', 'NumItem', 'ScriptTermProject', 'sendMail', 'SendMailUI']
    )